import sys
import time
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QPushButton
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtCore import QTimer
from detection import LineCrossDetector  # Import the detection module

class Dashboard(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle('Line Crossing Detection')
        self.setGeometry(100, 100, 800, 600)  # Set window size and position

        # Layout to hold video feed and alert
        self.layout = QVBoxLayout()

        # QLabel to display the video feed
        self.video_label = QLabel(self)
        self.layout.addWidget(self.video_label)

        # QLabel to show alert messages
        self.alert_label = QLabel(self)
        self.alert_label.setText("Waiting for person to cross the line...")
        self.layout.addWidget(self.alert_label)

        # Button to trigger analytics (optional)
        self.analytics_button = QPushButton('Show Analytics', self)
        self.layout.addWidget(self.analytics_button)

        # Initialize the LineCrossDetector
        self.detector = LineCrossDetector('yolov8n.pt', line_x_position=300, video_source='http://192.168.24.109:4747/video')

        # Timer to update video and check for line crossings
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_frame)
        self.timer.start(30)  # Update every 30ms

        self.setLayout(self.layout)

    def update_frame(self):
        frame, crossing_events, video_ended = self.detector.process_frame()

        if video_ended:
            self.timer.stop()

        if frame is not None:
            # Convert the frame to QImage and display it on QLabel
            height, width, channels = frame.shape
            bytes_per_line = 3 * width
            q_img = QImage(frame.data, width, height, bytes_per_line, QImage.Format_BGR888)
            pixmap = QPixmap.fromImage(q_img)
            self.video_label.setPixmap(pixmap)

            # Check for crossings and update alert
            if crossing_events:
                self.alert_label.setText("ALERT: Person crossed the safety line!")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = Dashboard()
    window.show()
    sys.exit(app.exec_())
