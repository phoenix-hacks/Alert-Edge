import sqlite3
from datetime import datetime

class Database:
    def __init__(self, db_name='line_cross_events.db'):
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()
        self._create_table()

    def _create_table(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                object_id INTEGER
            )
        ''')
        self.conn.commit()

    def log_event(self, object_id):
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        self.cursor.execute('INSERT INTO events (timestamp, object_id) VALUES (?, ?)', (timestamp, object_id))
        self.conn.commit()

    def fetch_all_events(self):
        self.cursor.execute('SELECT * FROM events')
        return self.cursor.fetchall()
